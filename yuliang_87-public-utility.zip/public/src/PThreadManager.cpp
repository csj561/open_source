/*
 * OWSThreadManager.cpp
 *
 *  Created on: Oct 17, 2013
 *      Author: yuliang
 */

#include "PThreadManager.h"

#include <stddef.h>

CPThreadManager* CPThreadManager::m_instance = NULL;

CPThreadManager::CPThreadManager() {
	// TODO Auto-generated constructor stub

}

CPThreadManager::~CPThreadManager() {
	// TODO Auto-generated destructor stub
}

CPThreadManager* CPThreadManager::Getinstance() {
	if (NULL == m_instance)
		m_instance = new CPThreadManager;
	return m_instance;
}

